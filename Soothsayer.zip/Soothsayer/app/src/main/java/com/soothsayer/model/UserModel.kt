package com.soothsayer.model

class UserModel{
    lateinit var id:Integer
    lateinit var userName:String
    lateinit var userEmail:String
    lateinit var userContact:String
}